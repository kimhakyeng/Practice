﻿
namespace KHK_portfolio
{
    partial class MYSELF
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MYSELF));
            FarPoint.Win.Spread.DefaultFocusIndicatorRenderer defaultFocusIndicatorRenderer1 = new FarPoint.Win.Spread.DefaultFocusIndicatorRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer1 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer2 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.lblName = new System.Windows.Forms.Label();
            this.picHobby = new System.Windows.Forms.PictureBox();
            this.picAddress = new System.Windows.Forms.PictureBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.picSelf = new System.Windows.Forms.PictureBox();
            this.comMBTI = new System.Windows.Forms.ComboBox();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.txtTitleBox = new System.Windows.Forms.TextBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.picMBTI = new System.Windows.Forms.PictureBox();
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.fpsAbility = new FarPoint.Win.Spread.FpSpread();
            this.fpsAbility_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.lblAdress = new System.Windows.Forms.Label();
            this.txtLocalBox = new System.Windows.Forms.TextBox();
            this.txtPhoneNumberBox = new System.Windows.Forms.TextBox();
            this.txtMailBox = new System.Windows.Forms.TextBox();
            this.lblPhone = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.lblMail = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtAgeBox = new System.Windows.Forms.TextBox();
            this.lblAge = new System.Windows.Forms.Label();
            this.txtNameBox = new System.Windows.Forms.TextBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.txthopeplace = new System.Windows.Forms.GroupBox();
            this.txthopeState = new System.Windows.Forms.TextBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.txtportfolio = new System.Windows.Forms.TextBox();
            this.aaaa = new System.Windows.Forms.GroupBox();
            this.txtSalary = new System.Windows.Forms.TextBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.txtEducationalHistory = new System.Windows.Forms.TextBox();
            this.txtCareer = new System.Windows.Forms.GroupBox();
            this.txtWorkHistory = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.picHobby)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAddress)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picSelf)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picMBTI)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).BeginInit();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpsAbility)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpsAbility_Sheet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox9.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.txthopeplace.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.aaaa.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.txtCareer.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.Color.Black;
            this.lblName.Location = new System.Drawing.Point(6, 19);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(171, 55);
            this.lblName.TabIndex = 22;
            this.lblName.Text = "Name ";
            // 
            // picHobby
            // 
            this.picHobby.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.picHobby.Dock = System.Windows.Forms.DockStyle.Fill;
            this.picHobby.Location = new System.Drawing.Point(3, 34);
            this.picHobby.Name = "picHobby";
            this.picHobby.Padding = new System.Windows.Forms.Padding(3);
            this.picHobby.Size = new System.Drawing.Size(309, 245);
            this.picHobby.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picHobby.TabIndex = 0;
            this.picHobby.TabStop = false;
            this.picHobby.Click += new System.EventHandler(this.picHobby_Click);
            this.picHobby.DoubleClick += new System.EventHandler(this.picHobby_DoubleClick);
            // 
            // picAddress
            // 
            this.picAddress.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.picAddress.Image = global::KHK_portfolio.Properties.Resources.map;
            this.picAddress.Location = new System.Drawing.Point(3, 380);
            this.picAddress.Name = "picAddress";
            this.picAddress.Size = new System.Drawing.Size(691, 141);
            this.picAddress.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picAddress.TabIndex = 0;
            this.picAddress.TabStop = false;
            this.picAddress.DoubleClick += new System.EventHandler(this.picAddress_DoubleClick);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.groupBox2.Controls.Add(this.picSelf);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Left;
            this.groupBox2.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(0, 0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(436, 524);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            // 
            // picSelf
            // 
            this.picSelf.Dock = System.Windows.Forms.DockStyle.Fill;
            this.picSelf.Location = new System.Drawing.Point(3, 19);
            this.picSelf.Name = "picSelf";
            this.picSelf.Size = new System.Drawing.Size(430, 502);
            this.picSelf.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picSelf.TabIndex = 0;
            this.picSelf.TabStop = false;
            this.picSelf.DoubleClick += new System.EventHandler(this.picSelf_DoubleClick);
            // 
            // comMBTI
            // 
            this.comMBTI.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.comMBTI.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comMBTI.ForeColor = System.Drawing.Color.Black;
            this.comMBTI.FormattingEnabled = true;
            this.comMBTI.Location = new System.Drawing.Point(56, 3);
            this.comMBTI.Name = "comMBTI";
            this.comMBTI.Size = new System.Drawing.Size(105, 28);
            this.comMBTI.TabIndex = 0;
            this.comMBTI.SelectedIndexChanged += new System.EventHandler(this.comMBTI_SelectedIndexChanged);
            this.comMBTI.TextChanged += new System.EventHandler(this.comMBTI_TextChanged);
            // 
            // splitContainer1
            // 
            this.splitContainer1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.groupBox7);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(1787, 805);
            this.splitContainer1.SplitterDistance = 76;
            this.splitContainer1.TabIndex = 1;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.txtTitleBox);
            this.groupBox7.Controls.Add(this.lblTitle);
            this.groupBox7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox7.Location = new System.Drawing.Point(0, 0);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(1787, 76);
            this.groupBox7.TabIndex = 0;
            this.groupBox7.TabStop = false;
            // 
            // txtTitleBox
            // 
            this.txtTitleBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtTitleBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold);
            this.txtTitleBox.Location = new System.Drawing.Point(202, 17);
            this.txtTitleBox.Name = "txtTitleBox";
            this.txtTitleBox.Size = new System.Drawing.Size(314, 44);
            this.txtTitleBox.TabIndex = 1;
            this.txtTitleBox.Text = "제목을 입력해주세요";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.Black;
            this.lblTitle.Location = new System.Drawing.Point(3, 17);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(118, 55);
            this.lblTitle.TabIndex = 23;
            this.lblTitle.Text = "Title";
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.groupBox1);
            this.splitContainer2.Panel1.Controls.Add(this.groupBox6);
            this.splitContainer2.Panel1.Controls.Add(this.groupBox2);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.groupBox9);
            this.splitContainer2.Size = new System.Drawing.Size(1787, 725);
            this.splitContainer2.SplitterDistance = 524;
            this.splitContainer2.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.splitContainer3);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(1133, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(654, 524);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(3, 17);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.groupBox5);
            this.splitContainer3.Panel1.Controls.Add(this.groupBox4);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.splitContainer4);
            this.splitContainer3.Size = new System.Drawing.Size(648, 504);
            this.splitContainer3.SplitterDistance = 282;
            this.splitContainer3.TabIndex = 0;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.picHobby);
            this.groupBox5.Dock = System.Windows.Forms.DockStyle.Left;
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold);
            this.groupBox5.Location = new System.Drawing.Point(315, 0);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(315, 282);
            this.groupBox5.TabIndex = 36;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "취미";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.comMBTI);
            this.groupBox4.Controls.Add(this.picMBTI);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Left;
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold);
            this.groupBox4.Location = new System.Drawing.Point(0, 0);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(315, 282);
            this.groupBox4.TabIndex = 35;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "성격";
            // 
            // picMBTI
            // 
            this.picMBTI.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(30)))), ((int)(((byte)(48)))));
            this.picMBTI.Dock = System.Windows.Forms.DockStyle.Fill;
            this.picMBTI.Image = ((System.Drawing.Image)(resources.GetObject("picMBTI.Image")));
            this.picMBTI.Location = new System.Drawing.Point(3, 34);
            this.picMBTI.Name = "picMBTI";
            this.picMBTI.Padding = new System.Windows.Forms.Padding(3);
            this.picMBTI.Size = new System.Drawing.Size(309, 245);
            this.picMBTI.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picMBTI.TabIndex = 0;
            this.picMBTI.TabStop = false;
            // 
            // splitContainer4
            // 
            this.splitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer4.Location = new System.Drawing.Point(0, 0);
            this.splitContainer4.Name = "splitContainer4";
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.fpsAbility);
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(this.chart1);
            this.splitContainer4.Size = new System.Drawing.Size(648, 218);
            this.splitContainer4.SplitterDistance = 469;
            this.splitContainer4.TabIndex = 0;
            // 
            // fpsAbility
            // 
            this.fpsAbility.AccessibleDescription = "fpsAbility, Sheet1, Row 0, Column 0, ";
            this.fpsAbility.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fpsAbility.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpsAbility.FocusRenderer = defaultFocusIndicatorRenderer1;
            this.fpsAbility.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.fpsAbility.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpsAbility.HorizontalScrollBar.Name = "";
            this.fpsAbility.HorizontalScrollBar.Renderer = defaultScrollBarRenderer1;
            this.fpsAbility.HorizontalScrollBar.TabIndex = 44;
            this.fpsAbility.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpsAbility.Location = new System.Drawing.Point(0, 0);
            this.fpsAbility.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.fpsAbility.Name = "fpsAbility";
            this.fpsAbility.ScrollBarTrackPolicy = FarPoint.Win.Spread.ScrollBarTrackPolicy.Both;
            this.fpsAbility.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpsAbility_Sheet1});
            this.fpsAbility.Size = new System.Drawing.Size(469, 218);
            this.fpsAbility.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic;
            this.fpsAbility.TabIndex = 7;
            this.fpsAbility.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpsAbility.VerticalScrollBar.Name = "";
            this.fpsAbility.VerticalScrollBar.Renderer = defaultScrollBarRenderer2;
            this.fpsAbility.VerticalScrollBar.TabIndex = 45;
            this.fpsAbility.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpsAbility.VisualStyles = FarPoint.Win.VisualStyles.Off;
            this.fpsAbility.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.fpsAbility_KeyPress);
            // 
            // fpsAbility_Sheet1
            // 
            this.fpsAbility_Sheet1.Reset();
            fpsAbility_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpsAbility_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            fpsAbility_Sheet1.ColumnCount = 2;
            fpsAbility_Sheet1.RowCount = 1;
            this.fpsAbility_Sheet1.AlternatingRows.Get(0).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.fpsAbility_Sheet1.AlternatingRows.Get(0).Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.fpsAbility_Sheet1.AlternatingRows.Get(0).ForeColor = System.Drawing.Color.Black;
            this.fpsAbility_Sheet1.AlternatingRows.Get(1).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.fpsAbility_Sheet1.AlternatingRows.Get(1).Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.fpsAbility_Sheet1.AlternatingRows.Get(1).ForeColor = System.Drawing.Color.Black;
            this.fpsAbility_Sheet1.Cells.Get(0, 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
            this.fpsAbility_Sheet1.Cells.Get(0, 0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.fpsAbility_Sheet1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpsAbility_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault";
            this.fpsAbility_Sheet1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpsAbility_Sheet1.ColumnFooterSheetCornerStyle.Parent = "CornerDefault";
            this.fpsAbility_Sheet1.ColumnHeader.Cells.Get(0, 0).ForeColor = System.Drawing.Color.Black;
            this.fpsAbility_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "핵심역량";
            this.fpsAbility_Sheet1.ColumnHeader.Cells.Get(0, 1).ForeColor = System.Drawing.Color.Black;
            this.fpsAbility_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "id";
            this.fpsAbility_Sheet1.ColumnHeader.DefaultStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.fpsAbility_Sheet1.ColumnHeader.DefaultStyle.Font = new System.Drawing.Font("맑은 고딕", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.fpsAbility_Sheet1.ColumnHeader.DefaultStyle.ForeColor = System.Drawing.Color.Black;
            this.fpsAbility_Sheet1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpsAbility_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault";
            this.fpsAbility_Sheet1.ColumnHeader.Rows.Get(0).Height = 43F;
            this.fpsAbility_Sheet1.Columns.Get(0).Font = new System.Drawing.Font("맑은 고딕", 15F, System.Drawing.FontStyle.Bold);
            this.fpsAbility_Sheet1.Columns.Get(0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
            this.fpsAbility_Sheet1.Columns.Get(0).Label = "핵심역량";
            this.fpsAbility_Sheet1.Columns.Get(0).Locked = false;
            this.fpsAbility_Sheet1.Columns.Get(0).Tag = "ABILITY_NAME";
            this.fpsAbility_Sheet1.Columns.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.fpsAbility_Sheet1.Columns.Get(0).Width = 570F;
            this.fpsAbility_Sheet1.Columns.Get(1).Font = new System.Drawing.Font("맑은 고딕", 15F, System.Drawing.FontStyle.Bold);
            this.fpsAbility_Sheet1.Columns.Get(1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
            this.fpsAbility_Sheet1.Columns.Get(1).Label = "id";
            this.fpsAbility_Sheet1.Columns.Get(1).Tag = "ID";
            this.fpsAbility_Sheet1.Columns.Get(1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.fpsAbility_Sheet1.Columns.Get(1).Visible = false;
            this.fpsAbility_Sheet1.Columns.Get(1).Width = 337F;
            this.fpsAbility_Sheet1.DefaultStyle.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
            this.fpsAbility_Sheet1.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpsAbility_Sheet1.DefaultStyle.Parent = "DataAreaDefault";
            this.fpsAbility_Sheet1.DefaultStyle.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Top;
            this.fpsAbility_Sheet1.GrayAreaBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.fpsAbility_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.fpsAbility_Sheet1.RowHeader.DefaultStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.fpsAbility_Sheet1.RowHeader.DefaultStyle.Font = new System.Drawing.Font("맑은 고딕", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.fpsAbility_Sheet1.RowHeader.DefaultStyle.ForeColor = System.Drawing.Color.Black;
            this.fpsAbility_Sheet1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpsAbility_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault";
            this.fpsAbility_Sheet1.Rows.Get(0).Height = 60F;
            this.fpsAbility_Sheet1.SheetCornerStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.fpsAbility_Sheet1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpsAbility_Sheet1.SheetCornerStyle.Parent = "CornerDefault";
            this.fpsAbility_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // chart1
            // 
            this.chart1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.chart1.BorderlineColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            chartArea1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            chartArea1.BackImageTransparentColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            chartArea1.BackSecondaryColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            chartArea1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            chartArea1.Name = "ChartArea1";
            chartArea1.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.chart1.ChartAreas.Add(chartArea1);
            this.chart1.Dock = System.Windows.Forms.DockStyle.Fill;
            legend1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            legend1.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Bottom;
            legend1.Enabled = false;
            legend1.Name = "Legend1";
            legend1.TitleBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(0, 0);
            this.chart1.Name = "chart1";
            this.chart1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None;
            this.chart1.PaletteCustomColors = new System.Drawing.Color[] {
        System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(177)))), ((int)(((byte)(171))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(244)))), ((int)(((byte)(244))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(158)))), ((int)(((byte)(120)))), ((int)(((byte)(239))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(122)))), ((int)(((byte)(215))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(8)))))};
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Doughnut;
            series1.IsVisibleInLegend = false;
            series1.LabelBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            series1.LabelBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(175, 218);
            this.chart1.TabIndex = 0;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.picAddress);
            this.groupBox6.Controls.Add(this.lblAdress);
            this.groupBox6.Controls.Add(this.txtLocalBox);
            this.groupBox6.Controls.Add(this.txtPhoneNumberBox);
            this.groupBox6.Controls.Add(this.txtMailBox);
            this.groupBox6.Controls.Add(this.lblPhone);
            this.groupBox6.Controls.Add(this.pictureBox3);
            this.groupBox6.Controls.Add(this.lblMail);
            this.groupBox6.Controls.Add(this.pictureBox2);
            this.groupBox6.Controls.Add(this.pictureBox1);
            this.groupBox6.Controls.Add(this.txtAgeBox);
            this.groupBox6.Controls.Add(this.lblAge);
            this.groupBox6.Controls.Add(this.txtNameBox);
            this.groupBox6.Controls.Add(this.lblName);
            this.groupBox6.Dock = System.Windows.Forms.DockStyle.Left;
            this.groupBox6.Location = new System.Drawing.Point(436, 0);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(697, 524);
            this.groupBox6.TabIndex = 3;
            this.groupBox6.TabStop = false;
            // 
            // lblAdress
            // 
            this.lblAdress.AutoSize = true;
            this.lblAdress.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdress.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblAdress.Location = new System.Drawing.Point(59, 347);
            this.lblAdress.Name = "lblAdress";
            this.lblAdress.Size = new System.Drawing.Size(333, 37);
            this.lblAdress.TabIndex = 34;
            this.lblAdress.Text = "충북 청주시 창직로 31번길";
            // 
            // txtLocalBox
            // 
            this.txtLocalBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtLocalBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold);
            this.txtLocalBox.Location = new System.Drawing.Point(65, 378);
            this.txtLocalBox.Name = "txtLocalBox";
            this.txtLocalBox.Size = new System.Drawing.Size(523, 44);
            this.txtLocalBox.TabIndex = 7;
            this.txtLocalBox.Text = "주소를 입력해주세요";
            // 
            // txtPhoneNumberBox
            // 
            this.txtPhoneNumberBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtPhoneNumberBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold);
            this.txtPhoneNumberBox.Location = new System.Drawing.Point(65, 279);
            this.txtPhoneNumberBox.Name = "txtPhoneNumberBox";
            this.txtPhoneNumberBox.Size = new System.Drawing.Size(523, 44);
            this.txtPhoneNumberBox.TabIndex = 5;
            this.txtPhoneNumberBox.Text = "전화번호를 입력해주세요";
            // 
            // txtMailBox
            // 
            this.txtMailBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtMailBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold);
            this.txtMailBox.Location = new System.Drawing.Point(66, 179);
            this.txtMailBox.Name = "txtMailBox";
            this.txtMailBox.Size = new System.Drawing.Size(522, 44);
            this.txtMailBox.TabIndex = 4;
            this.txtMailBox.Text = "메일 주소를 입력해주세요";
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhone.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblPhone.Location = new System.Drawing.Point(59, 245);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(246, 37);
            this.lblPhone.TabIndex = 30;
            this.lblPhone.Text = "010-3306-0340";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::KHK_portfolio.Properties.Resources.house;
            this.pictureBox3.Location = new System.Drawing.Point(12, 347);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(41, 35);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 28;
            this.pictureBox3.TabStop = false;
            // 
            // lblMail
            // 
            this.lblMail.AutoSize = true;
            this.lblMail.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMail.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblMail.Location = new System.Drawing.Point(60, 143);
            this.lblMail.Name = "lblMail";
            this.lblMail.Size = new System.Drawing.Size(369, 37);
            this.lblMail.TabIndex = 29;
            this.lblMail.Text = "rlagkrud32@nvaer.com";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::KHK_portfolio.Properties.Resources.phon;
            this.pictureBox2.Location = new System.Drawing.Point(12, 247);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(41, 27);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 27;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::KHK_portfolio.Properties.Resources.mail;
            this.pictureBox1.Location = new System.Drawing.Point(13, 142);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(41, 37);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 26;
            this.pictureBox1.TabStop = false;
            // 
            // txtAgeBox
            // 
            this.txtAgeBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtAgeBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold);
            this.txtAgeBox.Location = new System.Drawing.Point(159, 77);
            this.txtAgeBox.Name = "txtAgeBox";
            this.txtAgeBox.Size = new System.Drawing.Size(457, 44);
            this.txtAgeBox.TabIndex = 3;
            this.txtAgeBox.Text = "나이를 입력해주세요";
            // 
            // lblAge
            // 
            this.lblAge.AutoSize = true;
            this.lblAge.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAge.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblAge.Location = new System.Drawing.Point(80, 74);
            this.lblAge.Name = "lblAge";
            this.lblAge.Size = new System.Drawing.Size(73, 37);
            this.lblAge.TabIndex = 24;
            this.lblAge.Text = "age";
            // 
            // txtNameBox
            // 
            this.txtNameBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtNameBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold);
            this.txtNameBox.Location = new System.Drawing.Point(159, 20);
            this.txtNameBox.Name = "txtNameBox";
            this.txtNameBox.Size = new System.Drawing.Size(457, 44);
            this.txtNameBox.TabIndex = 2;
            this.txtNameBox.Text = "이름을 입력해주세요";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.groupBox8);
            this.groupBox9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox9.Location = new System.Drawing.Point(0, 0);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(1787, 197);
            this.groupBox9.TabIndex = 0;
            this.groupBox9.TabStop = false;
            // 
            // groupBox8
            // 
            this.groupBox8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(111)))), ((int)(((byte)(121)))), ((int)(((byte)(144)))));
            this.groupBox8.Controls.Add(this.tableLayoutPanel1);
            this.groupBox8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox8.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox8.Location = new System.Drawing.Point(3, 17);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(1781, 177);
            this.groupBox8.TabIndex = 0;
            this.groupBox8.TabStop = false;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Controls.Add(this.txthopeplace, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.groupBox12, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.aaaa, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.groupBox10, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.txtCareer, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 29);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1775, 145);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // txthopeplace
            // 
            this.txthopeplace.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(186)))), ((int)(((byte)(204)))));
            this.txthopeplace.Controls.Add(this.txthopeState);
            this.txthopeplace.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txthopeplace.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txthopeplace.Location = new System.Drawing.Point(1068, 3);
            this.txthopeplace.Name = "txthopeplace";
            this.txthopeplace.Size = new System.Drawing.Size(349, 139);
            this.txthopeplace.TabIndex = 4;
            this.txthopeplace.TabStop = false;
            this.txthopeplace.Text = "희망근무지/근무형태";
            // 
            // txthopeState
            // 
            this.txthopeState.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(186)))), ((int)(((byte)(204)))));
            this.txthopeState.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txthopeState.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txthopeState.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txthopeState.Location = new System.Drawing.Point(3, 35);
            this.txthopeState.Multiline = true;
            this.txthopeState.Name = "txthopeState";
            this.txthopeState.Size = new System.Drawing.Size(343, 101);
            this.txthopeState.TabIndex = 11;
            this.txthopeState.Text = "희망 근무지를 입력해주세요";
            this.txthopeState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox12
            // 
            this.groupBox12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(186)))), ((int)(((byte)(204)))));
            this.groupBox12.Controls.Add(this.txtportfolio);
            this.groupBox12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox12.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox12.Location = new System.Drawing.Point(1423, 3);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(349, 139);
            this.groupBox12.TabIndex = 3;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "포트폴리오";
            // 
            // txtportfolio
            // 
            this.txtportfolio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(186)))), ((int)(((byte)(204)))));
            this.txtportfolio.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtportfolio.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtportfolio.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtportfolio.Location = new System.Drawing.Point(3, 35);
            this.txtportfolio.Multiline = true;
            this.txtportfolio.Name = "txtportfolio";
            this.txtportfolio.Size = new System.Drawing.Size(343, 101);
            this.txtportfolio.TabIndex = 0;
            this.txtportfolio.Text = "-";
            this.txtportfolio.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // aaaa
            // 
            this.aaaa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(186)))), ((int)(((byte)(204)))));
            this.aaaa.Controls.Add(this.txtSalary);
            this.aaaa.Dock = System.Windows.Forms.DockStyle.Fill;
            this.aaaa.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aaaa.Location = new System.Drawing.Point(713, 3);
            this.aaaa.Name = "aaaa";
            this.aaaa.Size = new System.Drawing.Size(349, 139);
            this.aaaa.TabIndex = 2;
            this.aaaa.TabStop = false;
            this.aaaa.Text = "희망연봉";
            // 
            // txtSalary
            // 
            this.txtSalary.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(186)))), ((int)(((byte)(204)))));
            this.txtSalary.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSalary.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtSalary.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtSalary.Location = new System.Drawing.Point(3, 35);
            this.txtSalary.Multiline = true;
            this.txtSalary.Name = "txtSalary";
            this.txtSalary.Size = new System.Drawing.Size(343, 101);
            this.txtSalary.TabIndex = 10;
            this.txtSalary.Text = "희망연봉을 입력해주세요";
            this.txtSalary.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox10
            // 
            this.groupBox10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(186)))), ((int)(((byte)(204)))));
            this.groupBox10.Controls.Add(this.txtEducationalHistory);
            this.groupBox10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox10.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox10.Location = new System.Drawing.Point(3, 3);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(349, 139);
            this.groupBox10.TabIndex = 1;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "학력사항";
            // 
            // txtEducationalHistory
            // 
            this.txtEducationalHistory.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(186)))), ((int)(((byte)(204)))));
            this.txtEducationalHistory.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtEducationalHistory.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtEducationalHistory.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtEducationalHistory.Location = new System.Drawing.Point(3, 35);
            this.txtEducationalHistory.Multiline = true;
            this.txtEducationalHistory.Name = "txtEducationalHistory";
            this.txtEducationalHistory.Size = new System.Drawing.Size(343, 101);
            this.txtEducationalHistory.TabIndex = 8;
            this.txtEducationalHistory.Text = "학력사항을 입력해주세요";
            this.txtEducationalHistory.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtCareer
            // 
            this.txtCareer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(186)))), ((int)(((byte)(204)))));
            this.txtCareer.Controls.Add(this.txtWorkHistory);
            this.txtCareer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtCareer.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtCareer.Location = new System.Drawing.Point(358, 3);
            this.txtCareer.Name = "txtCareer";
            this.txtCareer.Size = new System.Drawing.Size(349, 139);
            this.txtCareer.TabIndex = 0;
            this.txtCareer.TabStop = false;
            this.txtCareer.Text = "경력사항";
            // 
            // txtWorkHistory
            // 
            this.txtWorkHistory.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(186)))), ((int)(((byte)(204)))));
            this.txtWorkHistory.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtWorkHistory.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtWorkHistory.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtWorkHistory.Location = new System.Drawing.Point(3, 35);
            this.txtWorkHistory.Multiline = true;
            this.txtWorkHistory.Name = "txtWorkHistory";
            this.txtWorkHistory.Size = new System.Drawing.Size(343, 101);
            this.txtWorkHistory.TabIndex = 9;
            this.txtWorkHistory.Text = "경력사항을 입력해주세요";
            this.txtWorkHistory.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // MYSELF
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1787, 805);
            this.Controls.Add(this.splitContainer1);
            this.Name = "MYSELF";
            this.TabText = "MySelf";
            this.Tag = "MySelf";
            this.Text = "MySelf";
            this.Load += new System.EventHandler(this.MYSELF_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picHobby)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAddress)).EndInit();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picSelf)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picMBTI)).EndInit();
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).EndInit();
            this.splitContainer4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fpsAbility)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpsAbility_Sheet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.txthopeplace.ResumeLayout(false);
            this.txthopeplace.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.aaaa.ResumeLayout(false);
            this.aaaa.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.txtCareer.ResumeLayout(false);
            this.txtCareer.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ComboBox comMBTI;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.PictureBox picSelf;
        private System.Windows.Forms.PictureBox picMBTI;
        private System.Windows.Forms.PictureBox picAddress;
        private System.Windows.Forms.PictureBox picHobby;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox txtAgeBox;
        private System.Windows.Forms.Label lblAge;
        private System.Windows.Forms.TextBox txtNameBox;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox txtTitleBox;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblAdress;
        private System.Windows.Forms.TextBox txtLocalBox;
        private System.Windows.Forms.TextBox txtPhoneNumberBox;
        private System.Windows.Forms.TextBox txtMailBox;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.Label lblMail;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.SplitContainer splitContainer4;
        private FarPoint.Win.Spread.FpSpread fpsAbility;
        private FarPoint.Win.Spread.SheetView fpsAbility_Sheet1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.GroupBox txtCareer;
        private System.Windows.Forms.TextBox txtWorkHistory;
        private System.Windows.Forms.GroupBox txthopeplace;
        private System.Windows.Forms.TextBox txthopeState;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.TextBox txtportfolio;
        private System.Windows.Forms.GroupBox aaaa;
        private System.Windows.Forms.TextBox txtSalary;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TextBox txtEducationalHistory;
    }
}