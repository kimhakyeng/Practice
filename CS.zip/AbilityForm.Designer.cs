﻿
namespace KHK_portfolio
{
    partial class AbilityForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            FarPoint.Win.Spread.DefaultFocusIndicatorRenderer defaultFocusIndicatorRenderer1 = new FarPoint.Win.Spread.DefaultFocusIndicatorRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer1 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer2 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer3 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer4 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer5 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer6 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer7 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer8 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.fpsSkills = new FarPoint.Win.Spread.FpSpread();
            this.fpsSkills_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.fpsExperience = new FarPoint.Win.Spread.FpSpread();
            this.fpsExperience_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.fpsWork = new FarPoint.Win.Spread.FpSpread();
            this.fpsWork_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.fpsAbility = new FarPoint.Win.Spread.FpSpread();
            this.fpsAbility_Sheet1 = new FarPoint.Win.Spread.SheetView();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpsSkills)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpsSkills_Sheet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpsExperience)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpsExperience_Sheet1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpsWork)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpsWork_Sheet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpsAbility)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpsAbility_Sheet1)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(113)))));
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer2);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.panel1);
            this.splitContainer1.Size = new System.Drawing.Size(1461, 675);
            this.splitContainer1.SplitterDistance = 736;
            this.splitContainer1.TabIndex = 0;
            // 
            // splitContainer2
            // 
            this.splitContainer2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.fpsSkills);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.fpsExperience);
            this.splitContainer2.Size = new System.Drawing.Size(736, 675);
            this.splitContainer2.SplitterDistance = 364;
            this.splitContainer2.TabIndex = 0;
            // 
            // fpsSkills
            // 
            this.fpsSkills.AccessibleDescription = "fpsSkills, Sheet1, Row 0, Column 0, ";
            this.fpsSkills.AllowColumnMove = true;
            this.fpsSkills.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(111)))), ((int)(((byte)(121)))), ((int)(((byte)(133)))));
            this.fpsSkills.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fpsSkills.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpsSkills.EditModeReplace = true;
            this.fpsSkills.FocusRenderer = defaultFocusIndicatorRenderer1;
            this.fpsSkills.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold);
            this.fpsSkills.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpsSkills.HorizontalScrollBar.Name = "";
            this.fpsSkills.HorizontalScrollBar.Renderer = defaultScrollBarRenderer1;
            this.fpsSkills.HorizontalScrollBar.TabIndex = 60;
            this.fpsSkills.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpsSkills.Location = new System.Drawing.Point(0, 0);
            this.fpsSkills.Name = "fpsSkills";
            this.fpsSkills.ScrollBarTrackPolicy = FarPoint.Win.Spread.ScrollBarTrackPolicy.Both;
            this.fpsSkills.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpsSkills_Sheet1});
            this.fpsSkills.Size = new System.Drawing.Size(736, 364);
            this.fpsSkills.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic;
            this.fpsSkills.TabIndex = 145;
            this.fpsSkills.TabStop = false;
            this.fpsSkills.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpsSkills.VerticalScrollBar.Name = "";
            this.fpsSkills.VerticalScrollBar.Renderer = defaultScrollBarRenderer2;
            this.fpsSkills.VerticalScrollBar.TabIndex = 61;
            this.fpsSkills.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpsSkills.VisualStyles = FarPoint.Win.VisualStyles.Off;
            this.fpsSkills.CellClick += new FarPoint.Win.Spread.CellClickEventHandler(this.fpsSkills_CellClick);
            this.fpsSkills.SetActiveViewport(0, -1, -1);
            // 
            // fpsSkills_Sheet1
            // 
            this.fpsSkills_Sheet1.Reset();
            fpsSkills_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpsSkills_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            fpsSkills_Sheet1.ColumnCount = 3;
            fpsSkills_Sheet1.RowCount = 0;
            this.fpsSkills_Sheet1.ActiveColumnIndex = -1;
            this.fpsSkills_Sheet1.ActiveRowIndex = -1;
            this.fpsSkills_Sheet1.AlternatingRows.Get(0).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.fpsSkills_Sheet1.AlternatingRows.Get(1).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(233)))));
            this.fpsSkills_Sheet1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpsSkills_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault";
            this.fpsSkills_Sheet1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpsSkills_Sheet1.ColumnFooterSheetCornerStyle.Parent = "CornerDefault";
            this.fpsSkills_Sheet1.ColumnHeader.Cells.Get(0, 0).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(233)))));
            this.fpsSkills_Sheet1.ColumnHeader.Cells.Get(0, 0).Font = new System.Drawing.Font("맑은 고딕", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.fpsSkills_Sheet1.ColumnHeader.Cells.Get(0, 0).ForeColor = System.Drawing.Color.Black;
            this.fpsSkills_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "취득 일자";
            this.fpsSkills_Sheet1.ColumnHeader.Cells.Get(0, 1).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(233)))));
            this.fpsSkills_Sheet1.ColumnHeader.Cells.Get(0, 1).Font = new System.Drawing.Font("맑은 고딕", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.fpsSkills_Sheet1.ColumnHeader.Cells.Get(0, 1).ForeColor = System.Drawing.Color.Black;
            this.fpsSkills_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "자격명";
            this.fpsSkills_Sheet1.ColumnHeader.Cells.Get(0, 2).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(233)))));
            this.fpsSkills_Sheet1.ColumnHeader.Cells.Get(0, 2).Font = new System.Drawing.Font("맑은 고딕", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.fpsSkills_Sheet1.ColumnHeader.Cells.Get(0, 2).ForeColor = System.Drawing.Color.Black;
            this.fpsSkills_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "비고";
            this.fpsSkills_Sheet1.ColumnHeader.DefaultStyle.BackColor = System.Drawing.Color.DimGray;
            this.fpsSkills_Sheet1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpsSkills_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault";
            this.fpsSkills_Sheet1.ColumnHeader.Rows.Get(0).Height = 56F;
            this.fpsSkills_Sheet1.Columns.Get(0).Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold);
            this.fpsSkills_Sheet1.Columns.Get(0).ForeColor = System.Drawing.Color.Black;
            this.fpsSkills_Sheet1.Columns.Get(0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.fpsSkills_Sheet1.Columns.Get(0).Label = "취득 일자";
            this.fpsSkills_Sheet1.Columns.Get(0).Locked = false;
            this.fpsSkills_Sheet1.Columns.Get(0).Tag = "DATE";
            this.fpsSkills_Sheet1.Columns.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.fpsSkills_Sheet1.Columns.Get(0).Width = 182F;
            this.fpsSkills_Sheet1.Columns.Get(1).Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold);
            this.fpsSkills_Sheet1.Columns.Get(1).ForeColor = System.Drawing.Color.Black;
            this.fpsSkills_Sheet1.Columns.Get(1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.fpsSkills_Sheet1.Columns.Get(1).Label = "자격명";
            this.fpsSkills_Sheet1.Columns.Get(1).Locked = false;
            this.fpsSkills_Sheet1.Columns.Get(1).Tag = "NAME";
            this.fpsSkills_Sheet1.Columns.Get(1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.fpsSkills_Sheet1.Columns.Get(1).Width = 276F;
            this.fpsSkills_Sheet1.Columns.Get(2).Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold);
            this.fpsSkills_Sheet1.Columns.Get(2).ForeColor = System.Drawing.Color.Black;
            this.fpsSkills_Sheet1.Columns.Get(2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.fpsSkills_Sheet1.Columns.Get(2).Label = "비고";
            this.fpsSkills_Sheet1.Columns.Get(2).Tag = "REMARK";
            this.fpsSkills_Sheet1.Columns.Get(2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.fpsSkills_Sheet1.Columns.Get(2).Width = 430F;
            this.fpsSkills_Sheet1.DefaultStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.fpsSkills_Sheet1.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpsSkills_Sheet1.DefaultStyle.Parent = "DataAreaDefault";
            this.fpsSkills_Sheet1.GrayAreaBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.fpsSkills_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.fpsSkills_Sheet1.RowHeader.DefaultStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(233)))));
            this.fpsSkills_Sheet1.RowHeader.DefaultStyle.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.fpsSkills_Sheet1.RowHeader.DefaultStyle.ForeColor = System.Drawing.Color.Black;
            this.fpsSkills_Sheet1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpsSkills_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault";
            this.fpsSkills_Sheet1.SheetCornerStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(81)))), ((int)(((byte)(216)))));
            this.fpsSkills_Sheet1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpsSkills_Sheet1.SheetCornerStyle.Parent = "CornerDefault";
            this.fpsSkills_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // fpsExperience
            // 
            this.fpsExperience.AccessibleDescription = "fpsExperience, Sheet1, Row 0, Column 0, ";
            this.fpsExperience.AllowColumnMove = true;
            this.fpsExperience.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(111)))), ((int)(((byte)(121)))), ((int)(((byte)(133)))));
            this.fpsExperience.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fpsExperience.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpsExperience.EditModeReplace = true;
            this.fpsExperience.FocusRenderer = defaultFocusIndicatorRenderer1;
            this.fpsExperience.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold);
            this.fpsExperience.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpsExperience.HorizontalScrollBar.Name = "";
            this.fpsExperience.HorizontalScrollBar.Renderer = defaultScrollBarRenderer3;
            this.fpsExperience.HorizontalScrollBar.TabIndex = 60;
            this.fpsExperience.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpsExperience.Location = new System.Drawing.Point(0, 0);
            this.fpsExperience.Name = "fpsExperience";
            this.fpsExperience.ScrollBarTrackPolicy = FarPoint.Win.Spread.ScrollBarTrackPolicy.Both;
            this.fpsExperience.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpsExperience_Sheet1});
            this.fpsExperience.Size = new System.Drawing.Size(736, 307);
            this.fpsExperience.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic;
            this.fpsExperience.TabIndex = 146;
            this.fpsExperience.TabStop = false;
            this.fpsExperience.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpsExperience.VerticalScrollBar.Name = "";
            this.fpsExperience.VerticalScrollBar.Renderer = defaultScrollBarRenderer4;
            this.fpsExperience.VerticalScrollBar.TabIndex = 61;
            this.fpsExperience.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpsExperience.VisualStyles = FarPoint.Win.VisualStyles.Off;
            this.fpsExperience.CellClick += new FarPoint.Win.Spread.CellClickEventHandler(this.fpsExperience_CellClick);
            this.fpsExperience.SetActiveViewport(0, -1, -1);
            // 
            // fpsExperience_Sheet1
            // 
            this.fpsExperience_Sheet1.Reset();
            fpsExperience_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpsExperience_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            fpsExperience_Sheet1.ColumnCount = 3;
            fpsExperience_Sheet1.RowCount = 0;
            this.fpsExperience_Sheet1.ActiveColumnIndex = -1;
            this.fpsExperience_Sheet1.ActiveRowIndex = -1;
            this.fpsExperience_Sheet1.AlternatingRows.Get(0).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.fpsExperience_Sheet1.AlternatingRows.Get(1).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(233)))));
            this.fpsExperience_Sheet1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpsExperience_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault";
            this.fpsExperience_Sheet1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpsExperience_Sheet1.ColumnFooterSheetCornerStyle.Parent = "CornerDefault";
            this.fpsExperience_Sheet1.ColumnHeader.Cells.Get(0, 0).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(233)))));
            this.fpsExperience_Sheet1.ColumnHeader.Cells.Get(0, 0).Font = new System.Drawing.Font("맑은 고딕", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.fpsExperience_Sheet1.ColumnHeader.Cells.Get(0, 0).ForeColor = System.Drawing.Color.Black;
            this.fpsExperience_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "기간";
            this.fpsExperience_Sheet1.ColumnHeader.Cells.Get(0, 1).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(233)))));
            this.fpsExperience_Sheet1.ColumnHeader.Cells.Get(0, 1).Font = new System.Drawing.Font("맑은 고딕", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.fpsExperience_Sheet1.ColumnHeader.Cells.Get(0, 1).ForeColor = System.Drawing.Color.Black;
            this.fpsExperience_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "활동 / 체험 명";
            this.fpsExperience_Sheet1.ColumnHeader.Cells.Get(0, 2).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(233)))));
            this.fpsExperience_Sheet1.ColumnHeader.Cells.Get(0, 2).Font = new System.Drawing.Font("맑은 고딕", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.fpsExperience_Sheet1.ColumnHeader.Cells.Get(0, 2).ForeColor = System.Drawing.Color.Black;
            this.fpsExperience_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "비고";
            this.fpsExperience_Sheet1.ColumnHeader.DefaultStyle.BackColor = System.Drawing.Color.DimGray;
            this.fpsExperience_Sheet1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpsExperience_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault";
            this.fpsExperience_Sheet1.ColumnHeader.Rows.Get(0).Height = 56F;
            this.fpsExperience_Sheet1.Columns.Get(0).Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold);
            this.fpsExperience_Sheet1.Columns.Get(0).ForeColor = System.Drawing.Color.Black;
            this.fpsExperience_Sheet1.Columns.Get(0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.fpsExperience_Sheet1.Columns.Get(0).Label = "기간";
            this.fpsExperience_Sheet1.Columns.Get(0).Locked = false;
            this.fpsExperience_Sheet1.Columns.Get(0).Tag = "DATE";
            this.fpsExperience_Sheet1.Columns.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.fpsExperience_Sheet1.Columns.Get(0).Width = 182F;
            this.fpsExperience_Sheet1.Columns.Get(1).Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold);
            this.fpsExperience_Sheet1.Columns.Get(1).ForeColor = System.Drawing.Color.Black;
            this.fpsExperience_Sheet1.Columns.Get(1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.fpsExperience_Sheet1.Columns.Get(1).Label = "활동 / 체험 명";
            this.fpsExperience_Sheet1.Columns.Get(1).Locked = false;
            this.fpsExperience_Sheet1.Columns.Get(1).Tag = "NAME";
            this.fpsExperience_Sheet1.Columns.Get(1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.fpsExperience_Sheet1.Columns.Get(1).Width = 292F;
            this.fpsExperience_Sheet1.Columns.Get(2).Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold);
            this.fpsExperience_Sheet1.Columns.Get(2).ForeColor = System.Drawing.Color.Black;
            this.fpsExperience_Sheet1.Columns.Get(2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.fpsExperience_Sheet1.Columns.Get(2).Label = "비고";
            this.fpsExperience_Sheet1.Columns.Get(2).Tag = "REMARK";
            this.fpsExperience_Sheet1.Columns.Get(2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.fpsExperience_Sheet1.Columns.Get(2).Width = 428F;
            this.fpsExperience_Sheet1.DefaultStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.fpsExperience_Sheet1.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpsExperience_Sheet1.DefaultStyle.Parent = "DataAreaDefault";
            this.fpsExperience_Sheet1.GrayAreaBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.fpsExperience_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.fpsExperience_Sheet1.RowHeader.DefaultStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(233)))));
            this.fpsExperience_Sheet1.RowHeader.DefaultStyle.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.fpsExperience_Sheet1.RowHeader.DefaultStyle.ForeColor = System.Drawing.Color.Black;
            this.fpsExperience_Sheet1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpsExperience_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault";
            this.fpsExperience_Sheet1.SheetCornerStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(48)))), ((int)(((byte)(108)))));
            this.fpsExperience_Sheet1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpsExperience_Sheet1.SheetCornerStyle.Parent = "CornerDefault";
            this.fpsExperience_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(111)))), ((int)(((byte)(121)))), ((int)(((byte)(133)))));
            this.panel1.Controls.Add(this.splitContainer3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(721, 675);
            this.panel1.TabIndex = 0;
            // 
            // splitContainer3
            // 
            this.splitContainer3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.fpsWork);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.fpsAbility);
            this.splitContainer3.Size = new System.Drawing.Size(721, 675);
            this.splitContainer3.SplitterDistance = 364;
            this.splitContainer3.TabIndex = 0;
            // 
            // fpsWork
            // 
            this.fpsWork.AccessibleDescription = "fpsWork, Sheet1, Row 0, Column 0, ";
            this.fpsWork.AllowColumnMove = true;
            this.fpsWork.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(111)))), ((int)(((byte)(121)))), ((int)(((byte)(133)))));
            this.fpsWork.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fpsWork.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpsWork.EditModeReplace = true;
            this.fpsWork.FocusRenderer = defaultFocusIndicatorRenderer1;
            this.fpsWork.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold);
            this.fpsWork.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpsWork.HorizontalScrollBar.Name = "";
            this.fpsWork.HorizontalScrollBar.Renderer = defaultScrollBarRenderer5;
            this.fpsWork.HorizontalScrollBar.TabIndex = 64;
            this.fpsWork.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpsWork.Location = new System.Drawing.Point(0, 0);
            this.fpsWork.Name = "fpsWork";
            this.fpsWork.ScrollBarTrackPolicy = FarPoint.Win.Spread.ScrollBarTrackPolicy.Both;
            this.fpsWork.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpsWork_Sheet1});
            this.fpsWork.Size = new System.Drawing.Size(721, 364);
            this.fpsWork.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic;
            this.fpsWork.TabIndex = 146;
            this.fpsWork.TabStop = false;
            this.fpsWork.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpsWork.VerticalScrollBar.Name = "";
            this.fpsWork.VerticalScrollBar.Renderer = defaultScrollBarRenderer6;
            this.fpsWork.VerticalScrollBar.TabIndex = 65;
            this.fpsWork.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpsWork.VisualStyles = FarPoint.Win.VisualStyles.Off;
            this.fpsWork.CellClick += new FarPoint.Win.Spread.CellClickEventHandler(this.fpsWork_CellClick);
            this.fpsWork.SetActiveViewport(0, -1, -1);
            // 
            // fpsWork_Sheet1
            // 
            this.fpsWork_Sheet1.Reset();
            fpsWork_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpsWork_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            fpsWork_Sheet1.ColumnCount = 3;
            fpsWork_Sheet1.RowCount = 0;
            this.fpsWork_Sheet1.ActiveColumnIndex = -1;
            this.fpsWork_Sheet1.ActiveRowIndex = -1;
            this.fpsWork_Sheet1.AlternatingRows.Get(0).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.fpsWork_Sheet1.AlternatingRows.Get(1).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(233)))));
            this.fpsWork_Sheet1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpsWork_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault";
            this.fpsWork_Sheet1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpsWork_Sheet1.ColumnFooterSheetCornerStyle.Parent = "CornerDefault";
            this.fpsWork_Sheet1.ColumnHeader.Cells.Get(0, 0).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(233)))));
            this.fpsWork_Sheet1.ColumnHeader.Cells.Get(0, 0).Font = new System.Drawing.Font("맑은 고딕", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.fpsWork_Sheet1.ColumnHeader.Cells.Get(0, 0).ForeColor = System.Drawing.Color.Black;
            this.fpsWork_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "근무기간";
            this.fpsWork_Sheet1.ColumnHeader.Cells.Get(0, 1).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(233)))));
            this.fpsWork_Sheet1.ColumnHeader.Cells.Get(0, 1).Font = new System.Drawing.Font("맑은 고딕", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.fpsWork_Sheet1.ColumnHeader.Cells.Get(0, 1).ForeColor = System.Drawing.Color.Black;
            this.fpsWork_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "회사명";
            this.fpsWork_Sheet1.ColumnHeader.Cells.Get(0, 2).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(233)))));
            this.fpsWork_Sheet1.ColumnHeader.Cells.Get(0, 2).Font = new System.Drawing.Font("맑은 고딕", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.fpsWork_Sheet1.ColumnHeader.Cells.Get(0, 2).ForeColor = System.Drawing.Color.Black;
            this.fpsWork_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "업무내용";
            this.fpsWork_Sheet1.ColumnHeader.DefaultStyle.BackColor = System.Drawing.Color.DimGray;
            this.fpsWork_Sheet1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpsWork_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault";
            this.fpsWork_Sheet1.ColumnHeader.Rows.Get(0).Height = 56F;
            this.fpsWork_Sheet1.Columns.Get(0).Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold);
            this.fpsWork_Sheet1.Columns.Get(0).ForeColor = System.Drawing.Color.Black;
            this.fpsWork_Sheet1.Columns.Get(0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.fpsWork_Sheet1.Columns.Get(0).Label = "근무기간";
            this.fpsWork_Sheet1.Columns.Get(0).Locked = false;
            this.fpsWork_Sheet1.Columns.Get(0).Tag = "DATE";
            this.fpsWork_Sheet1.Columns.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.fpsWork_Sheet1.Columns.Get(0).Width = 182F;
            this.fpsWork_Sheet1.Columns.Get(1).Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold);
            this.fpsWork_Sheet1.Columns.Get(1).ForeColor = System.Drawing.Color.Black;
            this.fpsWork_Sheet1.Columns.Get(1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.fpsWork_Sheet1.Columns.Get(1).Label = "회사명";
            this.fpsWork_Sheet1.Columns.Get(1).Locked = false;
            this.fpsWork_Sheet1.Columns.Get(1).Tag = "NAME";
            this.fpsWork_Sheet1.Columns.Get(1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.fpsWork_Sheet1.Columns.Get(1).Width = 252F;
            this.fpsWork_Sheet1.Columns.Get(2).Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold);
            this.fpsWork_Sheet1.Columns.Get(2).ForeColor = System.Drawing.Color.Black;
            this.fpsWork_Sheet1.Columns.Get(2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.fpsWork_Sheet1.Columns.Get(2).Label = "업무내용";
            this.fpsWork_Sheet1.Columns.Get(2).Tag = "REMARK";
            this.fpsWork_Sheet1.Columns.Get(2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.fpsWork_Sheet1.Columns.Get(2).Width = 425F;
            this.fpsWork_Sheet1.DefaultStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.fpsWork_Sheet1.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpsWork_Sheet1.DefaultStyle.Parent = "DataAreaDefault";
            this.fpsWork_Sheet1.GrayAreaBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.fpsWork_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.fpsWork_Sheet1.RowHeader.DefaultStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(233)))));
            this.fpsWork_Sheet1.RowHeader.DefaultStyle.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.fpsWork_Sheet1.RowHeader.DefaultStyle.ForeColor = System.Drawing.Color.Black;
            this.fpsWork_Sheet1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpsWork_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault";
            this.fpsWork_Sheet1.SheetCornerStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(131)))), ((int)(((byte)(58)))), ((int)(((byte)(180)))));
            this.fpsWork_Sheet1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpsWork_Sheet1.SheetCornerStyle.Parent = "CornerDefault";
            this.fpsWork_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // fpsAbility
            // 
            this.fpsAbility.AccessibleDescription = "fpsAbility, Sheet1, Row 0, Column 0, ";
            this.fpsAbility.AllowColumnMove = true;
            this.fpsAbility.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(111)))), ((int)(((byte)(121)))), ((int)(((byte)(133)))));
            this.fpsAbility.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fpsAbility.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpsAbility.EditModeReplace = true;
            this.fpsAbility.FocusRenderer = defaultFocusIndicatorRenderer1;
            this.fpsAbility.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold);
            this.fpsAbility.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpsAbility.HorizontalScrollBar.Name = "";
            this.fpsAbility.HorizontalScrollBar.Renderer = defaultScrollBarRenderer7;
            this.fpsAbility.HorizontalScrollBar.TabIndex = 60;
            this.fpsAbility.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpsAbility.Location = new System.Drawing.Point(0, 0);
            this.fpsAbility.Name = "fpsAbility";
            this.fpsAbility.ScrollBarTrackPolicy = FarPoint.Win.Spread.ScrollBarTrackPolicy.Both;
            this.fpsAbility.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpsAbility_Sheet1});
            this.fpsAbility.Size = new System.Drawing.Size(721, 307);
            this.fpsAbility.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic;
            this.fpsAbility.TabIndex = 146;
            this.fpsAbility.TabStop = false;
            this.fpsAbility.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpsAbility.VerticalScrollBar.Name = "";
            this.fpsAbility.VerticalScrollBar.Renderer = defaultScrollBarRenderer8;
            this.fpsAbility.VerticalScrollBar.TabIndex = 61;
            this.fpsAbility.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpsAbility.VisualStyles = FarPoint.Win.VisualStyles.Off;
            this.fpsAbility.CellClick += new FarPoint.Win.Spread.CellClickEventHandler(this.fpsAbility_CellClick);
            this.fpsAbility.SetActiveViewport(0, -1, -1);
            // 
            // fpsAbility_Sheet1
            // 
            this.fpsAbility_Sheet1.Reset();
            fpsAbility_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpsAbility_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            fpsAbility_Sheet1.ColumnCount = 2;
            fpsAbility_Sheet1.RowCount = 0;
            this.fpsAbility_Sheet1.ActiveColumnIndex = -1;
            this.fpsAbility_Sheet1.ActiveRowIndex = -1;
            this.fpsAbility_Sheet1.AlternatingRows.Get(0).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.fpsAbility_Sheet1.AlternatingRows.Get(1).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(233)))));
            this.fpsAbility_Sheet1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpsAbility_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault";
            this.fpsAbility_Sheet1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpsAbility_Sheet1.ColumnFooterSheetCornerStyle.Parent = "CornerDefault";
            this.fpsAbility_Sheet1.ColumnHeader.Cells.Get(0, 0).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(233)))));
            this.fpsAbility_Sheet1.ColumnHeader.Cells.Get(0, 0).Font = new System.Drawing.Font("맑은 고딕", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.fpsAbility_Sheet1.ColumnHeader.Cells.Get(0, 0).ForeColor = System.Drawing.Color.Black;
            this.fpsAbility_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "강점 및 장점";
            this.fpsAbility_Sheet1.ColumnHeader.Cells.Get(0, 1).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(233)))));
            this.fpsAbility_Sheet1.ColumnHeader.Cells.Get(0, 1).Font = new System.Drawing.Font("맑은 고딕", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.fpsAbility_Sheet1.ColumnHeader.Cells.Get(0, 1).ForeColor = System.Drawing.Color.Black;
            this.fpsAbility_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "비고";
            this.fpsAbility_Sheet1.ColumnHeader.DefaultStyle.BackColor = System.Drawing.Color.DimGray;
            this.fpsAbility_Sheet1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpsAbility_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault";
            this.fpsAbility_Sheet1.ColumnHeader.Rows.Get(0).Height = 56F;
            this.fpsAbility_Sheet1.Columns.Get(0).Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold);
            this.fpsAbility_Sheet1.Columns.Get(0).ForeColor = System.Drawing.Color.Black;
            this.fpsAbility_Sheet1.Columns.Get(0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.fpsAbility_Sheet1.Columns.Get(0).Label = "강점 및 장점";
            this.fpsAbility_Sheet1.Columns.Get(0).Locked = false;
            this.fpsAbility_Sheet1.Columns.Get(0).Tag = "NAME";
            this.fpsAbility_Sheet1.Columns.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.fpsAbility_Sheet1.Columns.Get(0).Width = 292F;
            this.fpsAbility_Sheet1.Columns.Get(1).Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold);
            this.fpsAbility_Sheet1.Columns.Get(1).ForeColor = System.Drawing.Color.Black;
            this.fpsAbility_Sheet1.Columns.Get(1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.fpsAbility_Sheet1.Columns.Get(1).Label = "비고";
            this.fpsAbility_Sheet1.Columns.Get(1).Tag = "REMARK";
            this.fpsAbility_Sheet1.Columns.Get(1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.fpsAbility_Sheet1.Columns.Get(1).Width = 445F;
            this.fpsAbility_Sheet1.DefaultStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.fpsAbility_Sheet1.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpsAbility_Sheet1.DefaultStyle.Parent = "DataAreaDefault";
            this.fpsAbility_Sheet1.GrayAreaBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.fpsAbility_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.fpsAbility_Sheet1.RowHeader.DefaultStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(233)))));
            this.fpsAbility_Sheet1.RowHeader.DefaultStyle.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.fpsAbility_Sheet1.RowHeader.DefaultStyle.ForeColor = System.Drawing.Color.Black;
            this.fpsAbility_Sheet1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpsAbility_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault";
            this.fpsAbility_Sheet1.SheetCornerStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(36)))), ((int)(((byte)(76)))));
            this.fpsAbility_Sheet1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpsAbility_Sheet1.SheetCornerStyle.Parent = "CornerDefault";
            this.fpsAbility_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // AbilityForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1461, 675);
            this.Controls.Add(this.splitContainer1);
            this.Name = "AbilityForm";
            this.TabText = "AbilityForm";
            this.Text = "AbilityForm";
            this.Load += new System.EventHandler(this.AbilityForm_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fpsSkills)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpsSkills_Sheet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpsExperience)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpsExperience_Sheet1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fpsWork)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpsWork_Sheet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpsAbility)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpsAbility_Sheet1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Panel panel1;
        private FarPoint.Win.Spread.FpSpread fpsSkills;
        private FarPoint.Win.Spread.SheetView fpsSkills_Sheet1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private FarPoint.Win.Spread.FpSpread fpsExperience;
        private FarPoint.Win.Spread.SheetView fpsExperience_Sheet1;
        private FarPoint.Win.Spread.FpSpread fpsWork;
        private FarPoint.Win.Spread.SheetView fpsWork_Sheet1;
        private FarPoint.Win.Spread.FpSpread fpsAbility;
        private FarPoint.Win.Spread.SheetView fpsAbility_Sheet1;
    }
}