﻿
namespace KHK_portfolio
{
    partial class MYHOPE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.panel7 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.Visionpanel0 = new System.Windows.Forms.Panel();
            this.printVisonTitle0 = new System.Windows.Forms.Label();
            this.Probar0 = new CircularProgressBar.CircularProgressBar();
            this.Visionpanel4 = new System.Windows.Forms.Panel();
            this.printVisonTitle4 = new System.Windows.Forms.Label();
            this.Probar4 = new CircularProgressBar.CircularProgressBar();
            this.Visionpanel2 = new System.Windows.Forms.Panel();
            this.printVisonTitle2 = new System.Windows.Forms.Label();
            this.Probar2 = new CircularProgressBar.CircularProgressBar();
            this.Visionpanel1 = new System.Windows.Forms.Panel();
            this.printVisonTitle1 = new System.Windows.Forms.Label();
            this.Probar1 = new CircularProgressBar.CircularProgressBar();
            this.Visionpanel3 = new System.Windows.Forms.Panel();
            this.printVisonTitle3 = new System.Windows.Forms.Label();
            this.Probar3 = new CircularProgressBar.CircularProgressBar();
            this.pnlVision = new System.Windows.Forms.Panel();
            this.VisionBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.txtVisionPer4 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.txtVisionTiltle4 = new System.Windows.Forms.TextBox();
            this.VisionBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.txtVisionPer3 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.txtVisionTiltle3 = new System.Windows.Forms.TextBox();
            this.VisionBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.txtVisionPer2 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.txtVisionTiltle2 = new System.Windows.Forms.TextBox();
            this.VisionBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.txtVisionPer1 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.txtVisionTiltle1 = new System.Windows.Forms.TextBox();
            this.VisionBox0 = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.txtVisionPer0 = new System.Windows.Forms.TextBox();
            this.textBox0 = new System.Windows.Forms.TextBox();
            this.txtVisionTiltle0 = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.btnResult = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.panel7.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.Visionpanel0.SuspendLayout();
            this.Visionpanel4.SuspendLayout();
            this.Visionpanel2.SuspendLayout();
            this.Visionpanel1.SuspendLayout();
            this.Visionpanel3.SuspendLayout();
            this.pnlVision.SuspendLayout();
            this.VisionBox4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.VisionBox3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.VisionBox2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.VisionBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.VisionBox0.SuspendLayout();
            this.panel6.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.panel9.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.panel2);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(1924, 614);
            this.splitContainer1.SplitterDistance = 49;
            this.splitContainer1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.panel2.Controls.Add(this.label2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1924, 49);
            this.panel2.TabIndex = 23;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Left;
            this.label2.Font = new System.Drawing.Font("Nirmala UI", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(239, 65);
            this.label2.TabIndex = 0;
            this.label2.Text = "MyVision";
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.panel7);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.pnlVision);
            this.splitContainer2.Size = new System.Drawing.Size(1924, 561);
            this.splitContainer2.SplitterDistance = 375;
            this.splitContainer2.TabIndex = 0;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.panel7.Controls.Add(this.tableLayoutPanel1);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Padding = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.panel7.Size = new System.Drawing.Size(1924, 375);
            this.panel7.TabIndex = 23;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Controls.Add(this.Visionpanel0, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.Visionpanel4, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.Visionpanel2, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.Visionpanel1, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.Visionpanel3, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 375F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1914, 375);
            this.tableLayoutPanel1.TabIndex = 4;
            // 
            // Visionpanel0
            // 
            this.Visionpanel0.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.Visionpanel0.Controls.Add(this.printVisonTitle0);
            this.Visionpanel0.Controls.Add(this.Probar0);
            this.Visionpanel0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Visionpanel0.Location = new System.Drawing.Point(1531, 3);
            this.Visionpanel0.Name = "Visionpanel0";
            this.Visionpanel0.Size = new System.Drawing.Size(380, 369);
            this.Visionpanel0.TabIndex = 3;
            // 
            // printVisonTitle0
            // 
            this.printVisonTitle0.AutoSize = true;
            this.printVisonTitle0.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.printVisonTitle0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.printVisonTitle0.Font = new System.Drawing.Font("Nirmala UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.printVisonTitle0.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(131)))), ((int)(((byte)(58)))), ((int)(((byte)(180)))));
            this.printVisonTitle0.Location = new System.Drawing.Point(0, 0);
            this.printVisonTitle0.Name = "printVisonTitle0";
            this.printVisonTitle0.Size = new System.Drawing.Size(148, 32);
            this.printVisonTitle0.TabIndex = 0;
            this.printVisonTitle0.Text = "Some Vision";
            // 
            // Probar0
            // 
            this.Probar0.AnimationFunction = WinFormAnimation.KnownAnimationFunctions.Liner;
            this.Probar0.AnimationSpeed = 500;
            this.Probar0.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.Probar0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Probar0.Font = new System.Drawing.Font("굴림", 36F, System.Drawing.FontStyle.Bold);
            this.Probar0.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(220)))), ((int)(((byte)(128)))));
            this.Probar0.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.Probar0.InnerMargin = 2;
            this.Probar0.InnerWidth = 50;
            this.Probar0.Location = new System.Drawing.Point(0, 0);
            this.Probar0.MarqueeAnimationSpeed = 2000;
            this.Probar0.Name = "Probar0";
            this.Probar0.OuterColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(10)))), ((int)(((byte)(230)))));
            this.Probar0.OuterMargin = -25;
            this.Probar0.OuterWidth = 26;
            this.Probar0.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(220)))), ((int)(((byte)(128)))));
            this.Probar0.ProgressWidth = 10;
            this.Probar0.SecondaryFont = new System.Drawing.Font("Microsoft Sans Serif", 36F);
            this.Probar0.Size = new System.Drawing.Size(380, 369);
            this.Probar0.StartAngle = 270;
            this.Probar0.SubscriptColor = System.Drawing.Color.White;
            this.Probar0.SubscriptMargin = new System.Windows.Forms.Padding(10, -35, 0, 0);
            this.Probar0.SubscriptText = "";
            this.Probar0.SuperscriptColor = System.Drawing.Color.White;
            this.Probar0.SuperscriptMargin = new System.Windows.Forms.Padding(10, 35, 0, 0);
            this.Probar0.SuperscriptText = "";
            this.Probar0.TabIndex = 1;
            this.Probar0.TextMargin = new System.Windows.Forms.Padding(8, 8, 0, 0);
            this.Probar0.Value = 68;
            // 
            // Visionpanel4
            // 
            this.Visionpanel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.Visionpanel4.Controls.Add(this.printVisonTitle4);
            this.Visionpanel4.Controls.Add(this.Probar4);
            this.Visionpanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Visionpanel4.Location = new System.Drawing.Point(3, 3);
            this.Visionpanel4.Name = "Visionpanel4";
            this.Visionpanel4.Size = new System.Drawing.Size(376, 369);
            this.Visionpanel4.TabIndex = 5;
            // 
            // printVisonTitle4
            // 
            this.printVisonTitle4.AutoSize = true;
            this.printVisonTitle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.printVisonTitle4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.printVisonTitle4.Font = new System.Drawing.Font("Nirmala UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.printVisonTitle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(131)))), ((int)(((byte)(58)))), ((int)(((byte)(180)))));
            this.printVisonTitle4.Location = new System.Drawing.Point(0, 0);
            this.printVisonTitle4.Name = "printVisonTitle4";
            this.printVisonTitle4.Size = new System.Drawing.Size(148, 32);
            this.printVisonTitle4.TabIndex = 0;
            this.printVisonTitle4.Text = "Some Vision";
            // 
            // Probar4
            // 
            this.Probar4.AnimationFunction = WinFormAnimation.KnownAnimationFunctions.Liner;
            this.Probar4.AnimationSpeed = 500;
            this.Probar4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.Probar4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Probar4.Font = new System.Drawing.Font("굴림", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Probar4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(53)))), ((int)(((byte)(132)))));
            this.Probar4.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.Probar4.InnerMargin = 2;
            this.Probar4.InnerWidth = 50;
            this.Probar4.Location = new System.Drawing.Point(0, 0);
            this.Probar4.MarqueeAnimationSpeed = 2000;
            this.Probar4.Name = "Probar4";
            this.Probar4.OuterColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(10)))), ((int)(((byte)(230)))));
            this.Probar4.OuterMargin = -25;
            this.Probar4.OuterWidth = 26;
            this.Probar4.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(53)))), ((int)(((byte)(132)))));
            this.Probar4.ProgressWidth = 10;
            this.Probar4.SecondaryFont = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Probar4.Size = new System.Drawing.Size(376, 369);
            this.Probar4.StartAngle = 270;
            this.Probar4.SubscriptColor = System.Drawing.Color.White;
            this.Probar4.SubscriptMargin = new System.Windows.Forms.Padding(10, -35, 0, 0);
            this.Probar4.SubscriptText = "";
            this.Probar4.SuperscriptColor = System.Drawing.Color.White;
            this.Probar4.SuperscriptMargin = new System.Windows.Forms.Padding(10, 35, 0, 0);
            this.Probar4.SuperscriptText = "";
            this.Probar4.TabIndex = 1;
            this.Probar4.TextMargin = new System.Windows.Forms.Padding(8, 8, 0, 0);
            this.Probar4.Value = 68;
            // 
            // Visionpanel2
            // 
            this.Visionpanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.Visionpanel2.Controls.Add(this.printVisonTitle2);
            this.Visionpanel2.Controls.Add(this.Probar2);
            this.Visionpanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Visionpanel2.Location = new System.Drawing.Point(767, 3);
            this.Visionpanel2.Name = "Visionpanel2";
            this.Visionpanel2.Size = new System.Drawing.Size(376, 369);
            this.Visionpanel2.TabIndex = 4;
            // 
            // printVisonTitle2
            // 
            this.printVisonTitle2.AutoSize = true;
            this.printVisonTitle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.printVisonTitle2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.printVisonTitle2.Font = new System.Drawing.Font("Nirmala UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.printVisonTitle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(131)))), ((int)(((byte)(58)))), ((int)(((byte)(180)))));
            this.printVisonTitle2.Location = new System.Drawing.Point(0, 0);
            this.printVisonTitle2.Name = "printVisonTitle2";
            this.printVisonTitle2.Size = new System.Drawing.Size(148, 32);
            this.printVisonTitle2.TabIndex = 0;
            this.printVisonTitle2.Text = "Some Vision";
            // 
            // Probar2
            // 
            this.Probar2.AnimationFunction = WinFormAnimation.KnownAnimationFunctions.Liner;
            this.Probar2.AnimationSpeed = 500;
            this.Probar2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.Probar2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Probar2.Font = new System.Drawing.Font("굴림", 36F, System.Drawing.FontStyle.Bold);
            this.Probar2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(119)))), ((int)(((byte)(55)))));
            this.Probar2.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.Probar2.InnerMargin = 2;
            this.Probar2.InnerWidth = 50;
            this.Probar2.Location = new System.Drawing.Point(0, 0);
            this.Probar2.MarqueeAnimationSpeed = 2000;
            this.Probar2.Name = "Probar2";
            this.Probar2.OuterColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(10)))), ((int)(((byte)(230)))));
            this.Probar2.OuterMargin = -25;
            this.Probar2.OuterWidth = 26;
            this.Probar2.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(119)))), ((int)(((byte)(55)))));
            this.Probar2.ProgressWidth = 10;
            this.Probar2.SecondaryFont = new System.Drawing.Font("Microsoft Sans Serif", 36F);
            this.Probar2.Size = new System.Drawing.Size(376, 369);
            this.Probar2.StartAngle = 270;
            this.Probar2.SubscriptColor = System.Drawing.Color.White;
            this.Probar2.SubscriptMargin = new System.Windows.Forms.Padding(10, -35, 0, 0);
            this.Probar2.SubscriptText = "";
            this.Probar2.SuperscriptColor = System.Drawing.Color.White;
            this.Probar2.SuperscriptMargin = new System.Windows.Forms.Padding(10, 35, 0, 0);
            this.Probar2.SuperscriptText = "";
            this.Probar2.TabIndex = 1;
            this.Probar2.TextMargin = new System.Windows.Forms.Padding(8, 8, 0, 0);
            this.Probar2.Value = 68;
            // 
            // Visionpanel1
            // 
            this.Visionpanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.Visionpanel1.Controls.Add(this.printVisonTitle1);
            this.Visionpanel1.Controls.Add(this.Probar1);
            this.Visionpanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Visionpanel1.Location = new System.Drawing.Point(1149, 3);
            this.Visionpanel1.Name = "Visionpanel1";
            this.Visionpanel1.Size = new System.Drawing.Size(376, 369);
            this.Visionpanel1.TabIndex = 2;
            // 
            // printVisonTitle1
            // 
            this.printVisonTitle1.AutoSize = true;
            this.printVisonTitle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.printVisonTitle1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.printVisonTitle1.Font = new System.Drawing.Font("Nirmala UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.printVisonTitle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(131)))), ((int)(((byte)(58)))), ((int)(((byte)(180)))));
            this.printVisonTitle1.Location = new System.Drawing.Point(0, 0);
            this.printVisonTitle1.Name = "printVisonTitle1";
            this.printVisonTitle1.Size = new System.Drawing.Size(148, 32);
            this.printVisonTitle1.TabIndex = 0;
            this.printVisonTitle1.Text = "Some Vision";
            // 
            // Probar1
            // 
            this.Probar1.AnimationFunction = WinFormAnimation.KnownAnimationFunctions.Liner;
            this.Probar1.AnimationSpeed = 500;
            this.Probar1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.Probar1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Probar1.Font = new System.Drawing.Font("굴림", 36F, System.Drawing.FontStyle.Bold);
            this.Probar1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(175)))), ((int)(((byte)(69)))));
            this.Probar1.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.Probar1.InnerMargin = 2;
            this.Probar1.InnerWidth = 50;
            this.Probar1.Location = new System.Drawing.Point(0, 0);
            this.Probar1.MarqueeAnimationSpeed = 2000;
            this.Probar1.Name = "Probar1";
            this.Probar1.OuterColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(10)))), ((int)(((byte)(230)))));
            this.Probar1.OuterMargin = -25;
            this.Probar1.OuterWidth = 26;
            this.Probar1.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(175)))), ((int)(((byte)(69)))));
            this.Probar1.ProgressWidth = 10;
            this.Probar1.SecondaryFont = new System.Drawing.Font("Microsoft Sans Serif", 36F);
            this.Probar1.Size = new System.Drawing.Size(376, 369);
            this.Probar1.StartAngle = 270;
            this.Probar1.SubscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(175)))), ((int)(((byte)(69)))));
            this.Probar1.SubscriptMargin = new System.Windows.Forms.Padding(10, -35, 0, 0);
            this.Probar1.SubscriptText = "";
            this.Probar1.SuperscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(175)))), ((int)(((byte)(69)))));
            this.Probar1.SuperscriptMargin = new System.Windows.Forms.Padding(10, 35, 0, 0);
            this.Probar1.SuperscriptText = "";
            this.Probar1.TabIndex = 1;
            this.Probar1.TextMargin = new System.Windows.Forms.Padding(8, 8, 0, 0);
            this.Probar1.Value = 68;
            // 
            // Visionpanel3
            // 
            this.Visionpanel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.Visionpanel3.Controls.Add(this.printVisonTitle3);
            this.Visionpanel3.Controls.Add(this.Probar3);
            this.Visionpanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Visionpanel3.Location = new System.Drawing.Point(385, 3);
            this.Visionpanel3.Name = "Visionpanel3";
            this.Visionpanel3.Size = new System.Drawing.Size(376, 369);
            this.Visionpanel3.TabIndex = 6;
            // 
            // printVisonTitle3
            // 
            this.printVisonTitle3.AutoSize = true;
            this.printVisonTitle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.printVisonTitle3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.printVisonTitle3.Font = new System.Drawing.Font("Nirmala UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.printVisonTitle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(131)))), ((int)(((byte)(58)))), ((int)(((byte)(180)))));
            this.printVisonTitle3.Location = new System.Drawing.Point(0, 0);
            this.printVisonTitle3.Name = "printVisonTitle3";
            this.printVisonTitle3.Size = new System.Drawing.Size(148, 32);
            this.printVisonTitle3.TabIndex = 0;
            this.printVisonTitle3.Text = "Some Vision";
            // 
            // Probar3
            // 
            this.Probar3.AnimationFunction = WinFormAnimation.KnownAnimationFunctions.Liner;
            this.Probar3.AnimationSpeed = 500;
            this.Probar3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.Probar3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Probar3.Font = new System.Drawing.Font("굴림", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Probar3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(36)))), ((int)(((byte)(76)))));
            this.Probar3.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.Probar3.InnerMargin = 2;
            this.Probar3.InnerWidth = 50;
            this.Probar3.Location = new System.Drawing.Point(0, 0);
            this.Probar3.MarqueeAnimationSpeed = 2000;
            this.Probar3.Name = "Probar3";
            this.Probar3.OuterColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(10)))), ((int)(((byte)(230)))));
            this.Probar3.OuterMargin = -25;
            this.Probar3.OuterWidth = 26;
            this.Probar3.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(36)))), ((int)(((byte)(76)))));
            this.Probar3.ProgressWidth = 10;
            this.Probar3.SecondaryFont = new System.Drawing.Font("Microsoft Sans Serif", 36F);
            this.Probar3.Size = new System.Drawing.Size(376, 369);
            this.Probar3.StartAngle = 270;
            this.Probar3.SubscriptColor = System.Drawing.Color.White;
            this.Probar3.SubscriptMargin = new System.Windows.Forms.Padding(10, -35, 0, 0);
            this.Probar3.SubscriptText = "";
            this.Probar3.SuperscriptColor = System.Drawing.Color.White;
            this.Probar3.SuperscriptMargin = new System.Windows.Forms.Padding(10, 35, 0, 0);
            this.Probar3.SuperscriptText = "";
            this.Probar3.TabIndex = 1;
            this.Probar3.Text = " ";
            this.Probar3.TextMargin = new System.Windows.Forms.Padding(8, 8, 0, 0);
            this.Probar3.Value = 68;
            // 
            // pnlVision
            // 
            this.pnlVision.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.pnlVision.Controls.Add(this.VisionBox4);
            this.pnlVision.Controls.Add(this.VisionBox3);
            this.pnlVision.Controls.Add(this.VisionBox2);
            this.pnlVision.Controls.Add(this.VisionBox1);
            this.pnlVision.Controls.Add(this.VisionBox0);
            this.pnlVision.Controls.Add(this.groupBox6);
            this.pnlVision.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlVision.Location = new System.Drawing.Point(0, 0);
            this.pnlVision.Margin = new System.Windows.Forms.Padding(20, 6, 20, 6);
            this.pnlVision.Name = "pnlVision";
            this.pnlVision.Padding = new System.Windows.Forms.Padding(5);
            this.pnlVision.Size = new System.Drawing.Size(1924, 182);
            this.pnlVision.TabIndex = 23;
            // 
            // VisionBox4
            // 
            this.VisionBox4.Controls.Add(this.groupBox10);
            this.VisionBox4.Controls.Add(this.panel5);
            this.VisionBox4.Dock = System.Windows.Forms.DockStyle.Left;
            this.VisionBox4.Location = new System.Drawing.Point(1410, 5);
            this.VisionBox4.Name = "VisionBox4";
            this.VisionBox4.Size = new System.Drawing.Size(281, 172);
            this.VisionBox4.TabIndex = 52;
            this.VisionBox4.TabStop = false;
            this.VisionBox4.Tag = "2";
            // 
            // groupBox10
            // 
            this.groupBox10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(53)))), ((int)(((byte)(132)))));
            this.groupBox10.Location = new System.Drawing.Point(5, 42);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(202, 10);
            this.groupBox10.TabIndex = 2;
            this.groupBox10.TabStop = false;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.panel5.Controls.Add(this.label6);
            this.panel5.Controls.Add(this.txtVisionPer4);
            this.panel5.Controls.Add(this.textBox4);
            this.panel5.Controls.Add(this.txtVisionTiltle4);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(3, 17);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(275, 152);
            this.panel5.TabIndex = 25;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.label6.Dock = System.Windows.Forms.DockStyle.Right;
            this.label6.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(247, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(28, 25);
            this.label6.TabIndex = 1;
            this.label6.Text = "%";
            // 
            // txtVisionPer4
            // 
            this.txtVisionPer4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.txtVisionPer4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtVisionPer4.Font = new System.Drawing.Font("Nirmala UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVisionPer4.ForeColor = System.Drawing.Color.Black;
            this.txtVisionPer4.Location = new System.Drawing.Point(214, -2);
            this.txtVisionPer4.Name = "txtVisionPer4";
            this.txtVisionPer4.Size = new System.Drawing.Size(34, 28);
            this.txtVisionPer4.TabIndex = 3;
            this.txtVisionPer4.Text = "100";
            this.txtVisionPer4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtVisionPer4_KeyPress);
            // 
            // textBox4
            // 
            this.textBox4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.textBox4.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox4.ForeColor = System.Drawing.Color.Black;
            this.textBox4.Location = new System.Drawing.Point(0, 37);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(275, 115);
            this.textBox4.TabIndex = 1;
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtVisionTiltle4
            // 
            this.txtVisionTiltle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.txtVisionTiltle4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtVisionTiltle4.Font = new System.Drawing.Font("Nirmala UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVisionTiltle4.ForeColor = System.Drawing.Color.Black;
            this.txtVisionTiltle4.Location = new System.Drawing.Point(1, -4);
            this.txtVisionTiltle4.Name = "txtVisionTiltle4";
            this.txtVisionTiltle4.Size = new System.Drawing.Size(200, 28);
            this.txtVisionTiltle4.TabIndex = 2;
            this.txtVisionTiltle4.Text = "5";
            // 
            // VisionBox3
            // 
            this.VisionBox3.Controls.Add(this.groupBox8);
            this.VisionBox3.Controls.Add(this.panel4);
            this.VisionBox3.Dock = System.Windows.Forms.DockStyle.Left;
            this.VisionBox3.Location = new System.Drawing.Point(1129, 5);
            this.VisionBox3.Name = "VisionBox3";
            this.VisionBox3.Size = new System.Drawing.Size(281, 172);
            this.VisionBox3.TabIndex = 51;
            this.VisionBox3.TabStop = false;
            this.VisionBox3.Tag = "2";
            // 
            // groupBox8
            // 
            this.groupBox8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(36)))), ((int)(((byte)(76)))));
            this.groupBox8.Location = new System.Drawing.Point(5, 42);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(202, 10);
            this.groupBox8.TabIndex = 2;
            this.groupBox8.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.panel4.Controls.Add(this.label5);
            this.panel4.Controls.Add(this.txtVisionPer3);
            this.panel4.Controls.Add(this.textBox3);
            this.panel4.Controls.Add(this.txtVisionTiltle3);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(3, 17);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(275, 152);
            this.panel4.TabIndex = 25;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Right;
            this.label5.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(247, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(28, 25);
            this.label5.TabIndex = 1;
            this.label5.Text = "%";
            // 
            // txtVisionPer3
            // 
            this.txtVisionPer3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.txtVisionPer3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtVisionPer3.Font = new System.Drawing.Font("Nirmala UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVisionPer3.ForeColor = System.Drawing.Color.Black;
            this.txtVisionPer3.Location = new System.Drawing.Point(214, -2);
            this.txtVisionPer3.Name = "txtVisionPer3";
            this.txtVisionPer3.Size = new System.Drawing.Size(34, 28);
            this.txtVisionPer3.TabIndex = 3;
            this.txtVisionPer3.Text = "100";
            this.txtVisionPer3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtVisionPer3_KeyPress);
            // 
            // textBox3
            // 
            this.textBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.textBox3.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox3.ForeColor = System.Drawing.Color.Black;
            this.textBox3.Location = new System.Drawing.Point(-3, 45);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(275, 115);
            this.textBox3.TabIndex = 1;
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtVisionTiltle3
            // 
            this.txtVisionTiltle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.txtVisionTiltle3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtVisionTiltle3.Font = new System.Drawing.Font("Nirmala UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVisionTiltle3.ForeColor = System.Drawing.Color.Black;
            this.txtVisionTiltle3.Location = new System.Drawing.Point(1, -4);
            this.txtVisionTiltle3.Name = "txtVisionTiltle3";
            this.txtVisionTiltle3.Size = new System.Drawing.Size(200, 28);
            this.txtVisionTiltle3.TabIndex = 2;
            this.txtVisionTiltle3.Text = "4";
            // 
            // VisionBox2
            // 
            this.VisionBox2.Controls.Add(this.groupBox5);
            this.VisionBox2.Controls.Add(this.panel3);
            this.VisionBox2.Dock = System.Windows.Forms.DockStyle.Left;
            this.VisionBox2.Location = new System.Drawing.Point(848, 5);
            this.VisionBox2.Name = "VisionBox2";
            this.VisionBox2.Size = new System.Drawing.Size(281, 172);
            this.VisionBox2.TabIndex = 50;
            this.VisionBox2.TabStop = false;
            this.VisionBox2.Tag = "2";
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(119)))), ((int)(((byte)(55)))));
            this.groupBox5.Location = new System.Drawing.Point(5, 42);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(202, 10);
            this.groupBox5.TabIndex = 2;
            this.groupBox5.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.txtVisionPer2);
            this.panel3.Controls.Add(this.textBox2);
            this.panel3.Controls.Add(this.txtVisionTiltle2);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(3, 17);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(275, 152);
            this.panel3.TabIndex = 25;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.label4.Dock = System.Windows.Forms.DockStyle.Right;
            this.label4.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(247, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(28, 25);
            this.label4.TabIndex = 1;
            this.label4.Text = "%";
            // 
            // txtVisionPer2
            // 
            this.txtVisionPer2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.txtVisionPer2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtVisionPer2.Font = new System.Drawing.Font("Nirmala UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVisionPer2.ForeColor = System.Drawing.Color.Black;
            this.txtVisionPer2.Location = new System.Drawing.Point(214, -2);
            this.txtVisionPer2.Name = "txtVisionPer2";
            this.txtVisionPer2.Size = new System.Drawing.Size(34, 28);
            this.txtVisionPer2.TabIndex = 3;
            this.txtVisionPer2.Text = "100";
            this.txtVisionPer2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtVisionPer2_KeyPress);
            // 
            // textBox2
            // 
            this.textBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.textBox2.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox2.ForeColor = System.Drawing.Color.Black;
            this.textBox2.Location = new System.Drawing.Point(0, 37);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(275, 115);
            this.textBox2.TabIndex = 1;
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtVisionTiltle2
            // 
            this.txtVisionTiltle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.txtVisionTiltle2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtVisionTiltle2.Font = new System.Drawing.Font("Nirmala UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVisionTiltle2.ForeColor = System.Drawing.Color.Black;
            this.txtVisionTiltle2.Location = new System.Drawing.Point(1, -4);
            this.txtVisionTiltle2.Name = "txtVisionTiltle2";
            this.txtVisionTiltle2.Size = new System.Drawing.Size(200, 28);
            this.txtVisionTiltle2.TabIndex = 2;
            this.txtVisionTiltle2.Text = "3";
            // 
            // VisionBox1
            // 
            this.VisionBox1.Controls.Add(this.groupBox3);
            this.VisionBox1.Controls.Add(this.panel1);
            this.VisionBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.VisionBox1.Location = new System.Drawing.Point(567, 5);
            this.VisionBox1.Name = "VisionBox1";
            this.VisionBox1.Size = new System.Drawing.Size(281, 172);
            this.VisionBox1.TabIndex = 49;
            this.VisionBox1.TabStop = false;
            this.VisionBox1.Tag = "2";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(175)))), ((int)(((byte)(69)))));
            this.groupBox3.Location = new System.Drawing.Point(5, 42);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(202, 10);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.txtVisionPer1);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.txtVisionTiltle1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 17);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(275, 152);
            this.panel1.TabIndex = 25;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.label3.Dock = System.Windows.Forms.DockStyle.Right;
            this.label3.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(247, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(28, 25);
            this.label3.TabIndex = 1;
            this.label3.Text = "%";
            // 
            // txtVisionPer1
            // 
            this.txtVisionPer1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.txtVisionPer1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtVisionPer1.Font = new System.Drawing.Font("Nirmala UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVisionPer1.ForeColor = System.Drawing.Color.Black;
            this.txtVisionPer1.Location = new System.Drawing.Point(214, -2);
            this.txtVisionPer1.Name = "txtVisionPer1";
            this.txtVisionPer1.Size = new System.Drawing.Size(34, 28);
            this.txtVisionPer1.TabIndex = 3;
            this.txtVisionPer1.Text = "100";
            this.txtVisionPer1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtVisionPer1_KeyPress);
            // 
            // textBox1
            // 
            this.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.textBox1.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox1.ForeColor = System.Drawing.Color.Black;
            this.textBox1.Location = new System.Drawing.Point(0, 37);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(275, 115);
            this.textBox1.TabIndex = 1;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtVisionTiltle1
            // 
            this.txtVisionTiltle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.txtVisionTiltle1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtVisionTiltle1.Font = new System.Drawing.Font("Nirmala UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVisionTiltle1.ForeColor = System.Drawing.Color.Black;
            this.txtVisionTiltle1.Location = new System.Drawing.Point(1, -4);
            this.txtVisionTiltle1.Name = "txtVisionTiltle1";
            this.txtVisionTiltle1.Size = new System.Drawing.Size(200, 28);
            this.txtVisionTiltle1.TabIndex = 2;
            this.txtVisionTiltle1.Text = "2";
            // 
            // VisionBox0
            // 
            this.VisionBox0.Controls.Add(this.groupBox1);
            this.VisionBox0.Controls.Add(this.panel6);
            this.VisionBox0.Dock = System.Windows.Forms.DockStyle.Left;
            this.VisionBox0.Location = new System.Drawing.Point(286, 5);
            this.VisionBox0.Name = "VisionBox0";
            this.VisionBox0.Size = new System.Drawing.Size(281, 172);
            this.VisionBox0.TabIndex = 48;
            this.VisionBox0.TabStop = false;
            this.VisionBox0.Tag = "2";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(220)))), ((int)(((byte)(128)))));
            this.groupBox1.Location = new System.Drawing.Point(5, 42);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(202, 10);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.panel6.Controls.Add(this.label11);
            this.panel6.Controls.Add(this.txtVisionPer0);
            this.panel6.Controls.Add(this.textBox0);
            this.panel6.Controls.Add(this.txtVisionTiltle0);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(3, 17);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(275, 152);
            this.panel6.TabIndex = 25;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.label11.Dock = System.Windows.Forms.DockStyle.Right;
            this.label11.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(247, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(28, 25);
            this.label11.TabIndex = 1;
            this.label11.Text = "%";
            // 
            // txtVisionPer0
            // 
            this.txtVisionPer0.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.txtVisionPer0.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtVisionPer0.Font = new System.Drawing.Font("Nirmala UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVisionPer0.ForeColor = System.Drawing.Color.Black;
            this.txtVisionPer0.Location = new System.Drawing.Point(214, -2);
            this.txtVisionPer0.MaxLength = 100;
            this.txtVisionPer0.Name = "txtVisionPer0";
            this.txtVisionPer0.Size = new System.Drawing.Size(34, 28);
            this.txtVisionPer0.TabIndex = 3;
            this.txtVisionPer0.Text = "100";
            this.txtVisionPer0.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtVisionPer0_KeyPress);
            // 
            // textBox0
            // 
            this.textBox0.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox0.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.textBox0.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox0.ForeColor = System.Drawing.Color.Black;
            this.textBox0.Location = new System.Drawing.Point(0, 37);
            this.textBox0.Multiline = true;
            this.textBox0.Name = "textBox0";
            this.textBox0.Size = new System.Drawing.Size(275, 115);
            this.textBox0.TabIndex = 1;
            this.textBox0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtVisionTiltle0
            // 
            this.txtVisionTiltle0.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.txtVisionTiltle0.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtVisionTiltle0.Font = new System.Drawing.Font("Nirmala UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVisionTiltle0.ForeColor = System.Drawing.Color.Black;
            this.txtVisionTiltle0.Location = new System.Drawing.Point(1, -4);
            this.txtVisionTiltle0.Name = "txtVisionTiltle0";
            this.txtVisionTiltle0.Size = new System.Drawing.Size(200, 28);
            this.txtVisionTiltle0.TabIndex = 2;
            this.txtVisionTiltle0.Text = "제목을 입력해주세요";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.panel9);
            this.groupBox6.Dock = System.Windows.Forms.DockStyle.Left;
            this.groupBox6.Location = new System.Drawing.Point(5, 5);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(281, 172);
            this.groupBox6.TabIndex = 37;
            this.groupBox6.TabStop = false;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(243)))));
            this.panel9.Controls.Add(this.label1);
            this.panel9.Controls.Add(this.label13);
            this.panel9.Controls.Add(this.label15);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(3, 17);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(275, 152);
            this.panel9.TabIndex = 25;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Nirmala UI", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(131)))), ((int)(((byte)(58)))), ((int)(((byte)(180)))));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "VisionTitle";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(0, 74);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(320, 100);
            this.label13.TabIndex = 0;
            this.label13.Text = "버튼을 눌러 자신의 Note를 추가하여\r\n자신의 목표나 \r\n앞으로의 성장 방행을 \r\n자유롭게 적어주세요.";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Nirmala UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(53)))), ((int)(((byte)(132)))));
            this.label15.Location = new System.Drawing.Point(157, 10);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(115, 20);
            this.label15.TabIndex = 0;
            this.label15.Text = "성취도 (ex 50%)";
            // 
            // btnResult
            // 
            this.btnResult.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnResult.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.btnResult.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnResult.Image = global::KHK_portfolio.Properties.Resources.BTN_RIGHT2;
            this.btnResult.Location = new System.Drawing.Point(0, 0);
            this.btnResult.Name = "btnResult";
            this.btnResult.Size = new System.Drawing.Size(52, 307);
            this.btnResult.TabIndex = 20;
            this.btnResult.UseVisualStyleBackColor = true;
            // 
            // MYHOPE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1924, 614);
            this.Controls.Add(this.splitContainer1);
            this.Name = "MYHOPE";
            this.TabText = "MYHOPE";
            this.Text = "MYHOPE";
            this.Load += new System.EventHandler(this.MYHOPE_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.Visionpanel0.ResumeLayout(false);
            this.Visionpanel0.PerformLayout();
            this.Visionpanel4.ResumeLayout(false);
            this.Visionpanel4.PerformLayout();
            this.Visionpanel2.ResumeLayout(false);
            this.Visionpanel2.PerformLayout();
            this.Visionpanel1.ResumeLayout(false);
            this.Visionpanel1.PerformLayout();
            this.Visionpanel3.ResumeLayout(false);
            this.Visionpanel3.PerformLayout();
            this.pnlVision.ResumeLayout(false);
            this.VisionBox4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.VisionBox3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.VisionBox2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.VisionBox1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.VisionBox0.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel pnlVision;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.GroupBox VisionBox0;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox textBox0;
        private CircularProgressBar.CircularProgressBar Probar1;
        private System.Windows.Forms.Button btnResult;
        private System.Windows.Forms.Panel Visionpanel1;
        private System.Windows.Forms.Label printVisonTitle1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel Visionpanel3;
        private System.Windows.Forms.Label printVisonTitle3;
        private CircularProgressBar.CircularProgressBar Probar3;
        private System.Windows.Forms.Panel Visionpanel4;
        private System.Windows.Forms.Label printVisonTitle4;
        private CircularProgressBar.CircularProgressBar Probar4;
        private System.Windows.Forms.Panel Visionpanel2;
        private System.Windows.Forms.Label printVisonTitle2;
        private CircularProgressBar.CircularProgressBar Probar2;
        private System.Windows.Forms.Panel Visionpanel0;
        private System.Windows.Forms.Label printVisonTitle0;
        private CircularProgressBar.CircularProgressBar Probar0;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtVisionPer0;
        private System.Windows.Forms.TextBox txtVisionTiltle0;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox VisionBox4;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtVisionPer4;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox txtVisionTiltle4;
        private System.Windows.Forms.GroupBox VisionBox3;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtVisionPer3;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox txtVisionTiltle3;
        private System.Windows.Forms.GroupBox VisionBox2;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtVisionPer2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox txtVisionTiltle2;
        private System.Windows.Forms.GroupBox VisionBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtVisionPer1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox txtVisionTiltle1;
    }
}