﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace KHK_portfolio
{  
    class Global
    {     
       
        public class Buttonoverride
        {
            public const string g_BtnSearch = "bSearch";
            public const string g_BtnNew = "bNew";
            public const string g_BtnSave = "bSave";
            public const string g_BtnDel = "bDel";
            public const string g_BtnRowAdd = "bRowAdd";
            public const string g_BtnRowDel = "bRowDel";
            public const string g_BtnClose = "bClose";
            public const string g_Resize = "Resize";
        }

       
      
        
    }


  


}
